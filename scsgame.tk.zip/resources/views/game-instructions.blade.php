@extends('layouts.base')
@section('content')
<div class="row">
  <div class="col">
    <h3>Instruções do Jogo.</h3>
    
  </div>
</div>

<div class="row">
  <div class="col text-center">
    <img class="img-fluid" src="{{ asset('images/scheme.svg') }}" alt="">
  </div>
</div>

@endsection()