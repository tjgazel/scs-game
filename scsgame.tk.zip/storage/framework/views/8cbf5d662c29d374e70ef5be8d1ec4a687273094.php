<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col text-center">
      <img src="<?php echo e(asset('images/scheme.svg')); ?>" alt="">
    </div>
  </div>
  <div class="row mt-5">
    <div class="col text-center">
      <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#newGameForm">
        <i class="fa fa-plus"></i> Iniciar novo jogo
      </button>
      <button type="button" class="btn btn-dark"><i class="fa fa-sign-in-alt"></i> Entrar em um jogo existente</button>
    </div>
  </div>
  
  <!-- Modal -->
  <div class="modal fade" id="newGameForm" tabindex="-1" role="dialog" aria-labelledby="newGameFormTitle" aria-hidden="true">
    <new-game-form url-action="<?php echo e(route('games.store')); ?>"></new-game-form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>