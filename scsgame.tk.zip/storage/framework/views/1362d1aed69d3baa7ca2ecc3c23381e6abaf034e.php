<?php $__env->startSection('title', 'Jogo: ' . $game->name . ' - '); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col text-center">
    <img src="<?php echo e(asset('images/scheme.svg')); ?>" alt="">
  </div>
</div>
<div class="row">
  <h1 class="col-12 text-center mb-3 text-success"><?php echo e($game->name); ?></h1>
  <h6 class="col-12 text-center">
    Escolha sua função no jogo<br>
    <small class="text-secondary">Note que você pode jogar sozinho, o computador faz pedidos automaticamente quando faltam algumas partes interessadas.</small>
  </h6>
</div>
<div class="row justify-content-center">
  <div class="col-md-6 mt-3 mb-3 text-center">
    <a href="<?php echo e(route('retailer.index', ['gameId' => $game->id])); ?>" class="btn btn-dark btn-block">
      <i class="fa fa-shopping-basket"></i> Varejista
    </a>
    <a href="<?php echo e(route('wholesaler.index', ['gameId' => $game->id])); ?>" class="btn btn-dark btn-block">
      <i class="fa fa-shopping-cart"></i> Atacadista
    </a>
    <a href="<?php echo e(route('distributer.index', ['gameId' => $game->id])); ?>" class="btn btn-dark btn-block">
      <i class="fa fa-briefcase"></i> Distribuidor
    </a>
    <a href="<?php echo e(route('manufacturer.index', ['gameId' => $game->id])); ?>" class="btn btn-dark btn-block">
      <i class="fa fa-industry"></i> Fabricante
    </a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>