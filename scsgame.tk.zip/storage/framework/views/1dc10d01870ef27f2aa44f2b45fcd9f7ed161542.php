<!-- Modal Create -->
<div class="modal fade" id="gameList" tabindex="-1" role="dialog" aria-labelledby="gameListTitle"
     aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="gameListTitle">
          <i class="fa fa-sign-in-alt"></i> Entrar em um jogo existente <br><br>
          <span class="float-right">
            <form class="form-inline">
              <input class="form-control form-control-sm mr-1" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success btn-sm" type="submit">Search</button>
            </form>
          </span>
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="overflow-y: auto; max-height: 400px">
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h5>
            <a href="<?php echo e(route('games.show', ['id' => $game->id])); ?>"><?php echo e($game->name); ?></a>
            <small class="float-right">
              <span>
                <i class="far fa-calendar"></i> <?php echo e($game->created_at); ?>

              </span>&nbsp;&nbsp;
              <?php if($game->status): ?>
                <span class="text-success">
                  <i class="far fa-flag"></i> Ativo
                </span>
              <?php else: ?>
                <span class="text-danger">
                  <i class="far fa-ban"></i> Finalizado
                </span>
              <?php endif; ?>
            </small>
          </h5>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
          <i class="fa fa-ban"></i> Cancelar
        </button>
      </div>
    </div>
  </div>
</div>