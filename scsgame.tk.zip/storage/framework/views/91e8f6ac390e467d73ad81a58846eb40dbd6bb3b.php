<?php $__env->startSection('title', 'Distribuidor em ' . $distributor->game->name . ' - '); ?>
<?php $__env->startSection('content'); ?>
  <menu-in-game
    stakeholder="distributor"
    data-json="<?php echo e($distributor); ?>"
    game-out-url="<?php echo e(route('distributor.gameout', ['id' => $distributor->id])); ?>">
  </menu-in-game>
  
  <distributor
    game-id="<?php echo e($distributor->game->id); ?>"
    submit-url="<?php echo e(route('distributor.your-order', ['gameId' => $distributor->game->id])); ?>"
    next-week-url="<?php echo e(route('distributor.next-week', ['gameId' => $distributor->game->id])); ?>"
    data-url="<?php echo e(route('distributor.stakeholder', ['gameId' => $distributor->game->id])); ?>"
    game-off-url="<?php echo e(route('games.show', ['gameId' => $distributor->game->id])); ?>">
  </distributor>
  
  <week-logs
    game-id="<?php echo e($distributor->game->id); ?>"
    data-url="<?php echo e(route('distributor.weeklog', ['gameId' => $distributor->game->id])); ?>">
  </week-logs>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base-vue', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>