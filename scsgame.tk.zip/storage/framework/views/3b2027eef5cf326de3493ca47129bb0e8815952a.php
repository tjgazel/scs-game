<?php $__env->startSection('title', 'Fabricante em ' . $manufacturer->game->name . ' - '); ?>
<?php $__env->startSection('content'); ?>
  <menu-in-game
    stakeholder="manufacturer"
    data-json="<?php echo e($manufacturer); ?>"
    game-out-url="<?php echo e(route('manufacturer.gameout', ['id' => $manufacturer->id])); ?>">
  </menu-in-game>
  
  <manufacturer
    game-id="<?php echo e($manufacturer->game->id); ?>"
    submit-url="<?php echo e(route('manufacturer.your-order', ['gameId' => $manufacturer->game->id])); ?>"
    next-week-url="<?php echo e(route('manufacturer.next-week', ['gameId' => $manufacturer->game->id])); ?>"
    data-url="<?php echo e(route('manufacturer.stakeholder', ['gameId' => $manufacturer->game->id])); ?>"
    game-off-url="<?php echo e(route('games.show', ['gameId' => $manufacturer->game->id])); ?>">
  </manufacturer>
  
  <week-log
    game-id="<?php echo e($manufacturer->game->id); ?>"
    data-url="<?php echo e(route('manufacturer.weeklog', ['gameId' => $manufacturer->game->id])); ?>">
  </week-log>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base-vue', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>