<?php $__env->startSection('title', 'Varejista em ' . $retailer->game->name . ' - '); ?>
<?php $__env->startSection('content'); ?>
  <menu-in-game
    stakeholder="retailer"
    data-json="<?php echo e($retailer); ?>"
    game-out-url="<?php echo e(route('retailer.gameout', ['id' => $retailer->id])); ?>">
  </menu-in-game>
  
  <retailer
    game-id="<?php echo e($retailer->game->id); ?>"
    submit-url="<?php echo e(route('retailer.your-order', ['gameId' => $retailer->game->id])); ?>"
    next-week-url="<?php echo e(route('retailer.next-week', ['gameId' => $retailer->game->id])); ?>"
    data-url="<?php echo e(route('retailer.stakeholder', ['gameId' => $retailer->game->id])); ?>"
    game-off-url="<?php echo e(route('games.show', ['gameId' => $retailer->game->id])); ?>">
  </retailer>
  
  <week-log
    game-id="<?php echo e($retailer->game->id); ?>"
    data-url="<?php echo e(route('retailer.weeklog', ['gameId' => $retailer->game->id])); ?>">
  </week-log>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base-vue', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>