<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col text-center">
      <img src="<?php echo e(asset('images/scheme.svg')); ?>" alt="">
    </div>
  </div>
  <div class="row mt-5">
    <div class="col text-center">
      <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#newGameForm">
        <i class="fa fa-plus"></i> Iniciar novo jogo
      </button>
      <button type="button" class="btn btn-dark"><i class="fa fa-sign-in-alt"></i> Entrar em um jogo existente</button>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="newGameForm" tabindex="-1" role="dialog" aria-labelledby="newGameFormTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="newGameFormTitle"><i class="fa fa-plus"></i> Iniciar novo jogo</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="POST" action="<?php echo e(route('games.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="name">Apelido</label>
              <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>"  autofocus>
              <?php if($errors->has('name')): ?>
                <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
              <?php endif; ?>
            </div>
            <div class="form-group mb-0">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">
                <i class="fa fa-ban"></i> Cancelar
              </button>
              <button type="submit" class="btn btn-dark">
                <i class="fa fa-play"></i> Start
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>