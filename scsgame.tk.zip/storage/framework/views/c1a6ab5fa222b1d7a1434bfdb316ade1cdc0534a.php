<?php $__env->startSection('title', 'Meus dados - ' ); ?>
<?php $__env->startSection('content'); ?>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header"><i class="fa fa-user"></i> Meus dados</div>
        
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('users.update', ['id' => $user->id])); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
            
            <div class="form-group">
              <label for="name">Apelido</label>
              <input id="name" name="name" type="text"
                     class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                     value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php else: ?><?php echo e(auth()->user()->name); ?><?php endif; ?>" required>
              
              <?php if($errors->has('name')): ?>
                <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
              <?php endif; ?>
            </div>
            
            <div class="form-group">
              <label for="email">E-mail</label>
              <input id="email" name="email" type="email"
                     class="form-control<?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
                     value="<?php if(old('email')): ?><?php echo e(old('email')); ?><?php else: ?><?php echo e(auth()->user()->email); ?><?php endif; ?>" required>
              
              <?php if($errors->has('email')): ?>
                <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
              <?php endif; ?>
            </div>
            
            <div class="form-group">
              <label for="password">Alterar Senha <small class="text-info">(alteração opcional)</small></label>
              <input id="password" type="password"
                     class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
              
              <?php if($errors->has('password')): ?>
                <span class="invalid-feedback">
                <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
              <?php endif; ?>
            </div>
            
            <div class="form-group">
              <label for="password-confirm">Confirmar nova senha</label>
              <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
            </div>
            
            <div class="form-group mb-0">
              <button type="submit" class="btn btn-dark btn-block">
                <i class="fa fa-save"></i> Salvar
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>