<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col">
    <h3>Instruções do Jogo.</h3>
    
  </div>
</div>

<div class="row">
  <div class="col text-center">
    <img src="<?php echo e(asset('images/scheme.svg')); ?>" alt="">
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>