<?php $__env->startSection('title', 'Iniciar ou entrar no jogo - '); ?>
<?php $__env->startSection('content'); ?>
  <div class="row mb-5">
    <div class="col text-center">
      <img class="img-fluid" src="<?php echo e(asset('images/scheme.svg')); ?>" alt="">
    </div>
  </div>
  <div class="row">
    <div class="col text-center">
      <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#newGameForm">
        <i class="fa fa-plus"></i> Iniciar novo jogo
      </button>
      <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#gameList">
        <i class="fa fa-sign-in-alt"></i> Entrar em um jogo existente
      </button>
    </div>
  </div>
  
  <!-- Modal Create -->
  <?php echo $__env->make('games.modal-create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  
  <game-list data="<?php echo e($games); ?>"></game-list>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>