<?php $__env->startSection('title', 'Game: ' . $game->name . ' - '); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col text-center">
    <h1>Resultados do jogo <br><small><i class="fa fa-play"></i> <?php echo e($game->name); ?></small></h1>
  </div>
</div>
<div class="row">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>