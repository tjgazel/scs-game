<?php $__env->startSection('title', 'Atacadista em ' . $wholesaler->game->name . ' - '); ?>
<?php $__env->startSection('content'); ?>
  <menu-in-game
    stakeholder="wholesaler"
    data-json="<?php echo e($wholesaler); ?>"
    game-out-url="<?php echo e(route('wholesaler.gameout', ['id' => $wholesaler->id])); ?>">
  </menu-in-game>
  
  <wholesaler
    game-id="<?php echo e($wholesaler->game->id); ?>"
    submit-url="<?php echo e(route('wholesaler.your-order', ['gameId' => $wholesaler->game->id])); ?>"
    next-week-url="<?php echo e(route('wholesaler.next-week', ['gameId' => $wholesaler->game->id])); ?>"
    data-url="<?php echo e(route('wholesaler.stakeholder', ['gameId' => $wholesaler->game->id])); ?>"
    game-off-url="<?php echo e(route('games.show', ['gameId' => $wholesaler->game->id])); ?>">
  </wholesaler>
  
  <week-log
    game-id="<?php echo e($wholesaler->game->id); ?>"
    data-url="<?php echo e(route('wholesaler.weeklog', ['gameId' => $wholesaler->game->id])); ?>">
  </week-log>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base-vue', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>