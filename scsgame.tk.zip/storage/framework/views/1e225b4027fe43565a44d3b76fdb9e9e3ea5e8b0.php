<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="app-url" content="<?php echo e(config('app.url')); ?>">

  <title><?php echo $__env->yieldContent('title'); ?><?php echo e(config('app.name'), 'SCS Game'); ?></title>

  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
</head>
<body>
  <div id="app">
    <header>
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <main>
      <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </main>
    <footer>

    </footer>
  </div>
  <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>
  <?php echo toastr()->render(); ?>

</body>
</html>